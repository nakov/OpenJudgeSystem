
namespace Database.Tests
{
    using NUnit.Framework;
    using System;
    using System.Data.Common;

    [TestFixture]
    public class DatabaseTests
    {

        //int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        //[SetUp]
        //public void Setup()
        //{
        //    
        //}

        [Test]
        public void TestArrayCapacity()
        {
            //int[] numbers = new int[16];
            //Database db = new Database(new int[16]);
            Assert.Throws<InvalidOperationException>(() => new Database(new int[17]));
            //Assert.That(16, Is.EqualTo(db.Count));
        }

        [Test]
        public void TestAddMethod()
        {
            int[] numbers = new int[16];
            Database db = new Database(numbers);
            Assert.Throws<InvalidOperationException>(() => db.Add(1));
            //db.Add(1);
        }

        [Test]
        public void TestRemoveMethod()
        {
            Database db = new Database(new int[0]);
            Assert.Throws<InvalidOperationException>(() => db.Remove());
        }

        //[Test]
        //public void TestConstructorDataType()
        //{
        //    //string[] strings = new string[16];
        //    //int[] ints = new int[16];
        //    //Assert.Throws<InvalidOperationException>(() => new Database(strings));
        //
        //    throw new NotImplementedException();
        //}

        [Test]
        public void TestFetchMethod()
        {
            Database db = new Database(new int[16]);
            int[] numbersFromDB = db.Fetch();
            Assert.AreEqual(numbersFromDB.Length, db.Count);
        }
    }
}

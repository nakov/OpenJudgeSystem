﻿namespace _01._ListyIterator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string command = Console.ReadLine();

            ListyIterator<string> listyIterator = null;

            while (command != "END")
            {
                string[] commandInfo = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (commandInfo[0] == "Create")
                {
                    List<string> items = commandInfo.Skip(1).ToList();

                    listyIterator = new ListyIterator<string>(items);
                }
                else if (commandInfo[0] == "Print")
                {
                    try
                    {
                        listyIterator.Print();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);

                    }
                }
                else if (commandInfo[0] == "Move")
                {
                    Console.WriteLine(listyIterator.Move());
                }
                else if (commandInfo[0] == "HasNext")
                {
                    Console.WriteLine(listyIterator.HasNext());
                }

                command = Console.ReadLine();
            }
        }
    }
}

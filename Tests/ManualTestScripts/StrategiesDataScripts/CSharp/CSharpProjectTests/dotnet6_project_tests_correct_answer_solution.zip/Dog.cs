﻿using System;

namespace Farm;

    internal class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }

    }
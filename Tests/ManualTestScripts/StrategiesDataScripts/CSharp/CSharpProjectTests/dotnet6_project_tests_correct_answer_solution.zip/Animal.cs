﻿using System;

namespace Farm;

internal class Animal
{
    public void Eat()
    {
        Console.WriteLine("eating...");
    }
}

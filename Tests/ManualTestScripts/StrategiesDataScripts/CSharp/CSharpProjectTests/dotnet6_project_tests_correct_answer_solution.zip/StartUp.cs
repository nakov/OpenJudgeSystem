﻿using System;

namespace Farm;

public class StartUp
{
    static void Main()
    {
        Dog dog = new();
        Puppy puppy = new();
        Cat cat = new Cat();
        puppy.Eat();
        puppy.Bark();
        puppy.Weep();
        cat.Eat();
    }
}

﻿using System;

namespace Farm
{
    internal class Cat : Animal
    {
        static void Meow()
        {
            Console.WriteLine("meoing...");
        }
    }
}

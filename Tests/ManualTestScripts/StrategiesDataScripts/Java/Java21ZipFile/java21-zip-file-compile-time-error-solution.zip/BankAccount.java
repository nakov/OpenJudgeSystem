package zad;

public class BankAccount {
    private static int idCounter = 1; // Static field to track ID creation
    private static double interestRate = 0.02; // Static field for shared interest rate

    private int id;
    private double balance;

    public BankAccount() {
        this.id = idCounter++;
        this.balance = 0;
    }

    public static void setInterestRate(double interest) {
        interestRate = interest;
    }

    public double getInterest(int years) {
        return this.balance * interestRate * years;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            this.balance += amount;
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public int getId() {
        return this.id;
    }

    public double getBalance() {
        return this.balance;
    }
}


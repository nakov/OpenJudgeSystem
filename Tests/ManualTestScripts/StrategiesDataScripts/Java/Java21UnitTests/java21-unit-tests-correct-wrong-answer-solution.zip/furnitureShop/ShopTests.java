package furnitureShop;

//TODO write unit tests

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ShopTests {

    private Shop shop;
    private Furniture furniture;

    @BeforeEach
    public void setUp() {
        shop = new Shop("VintageStuff", 3);
        furniture = new Furniture("RoyalBed", "Bed", 300);

        shop.addFurniture(furniture);
    }

    @Test
    public void getCountShouldReturnOne() {
        int actualCount = shop.getCount();
        int expectedCount = 1;
        Assertions.assertEquals(expectedCount, actualCount);
    }

    @Test
    public void getFurnitureShouldReturnCorrectList() {
        Collection<Furniture> expected = new ArrayList<>();
        expected.add(furniture);

        Collection<Furniture> actualD = shop.getFurnitures();

        Assertions.assertEquals(expected, actualD);
    }

    @Test
    public void addFurniture() {

        int actualCount = shop.getCount();
        int expectedCount = 1;
        Assertions.assertEquals(expectedCount, actualCount);
    }


    @Test
    public void removeFurniture() {
        shop.removeFurniture(furniture.getType());

        int actualCount = shop.getCount();
        int expectedCount = 0;
        Assertions.assertEquals(expectedCount, actualCount);
    }

    @Test
    public void addFurnitureWithNullValue() {

        assertThrows(IllegalArgumentException.class, () -> {
            shop.addFurniture(null);
        });
    }

//    @Test(expected = IllegalArgumentException.class)
//    public void addFurnitureWithNullValue() {
//
//        shop.addFurniture(null);
//    }

    @Test
    public void findCheapestFurniture() {
        Shop vintage = new Shop("Vintage", 5);
        Furniture furniture2 = new Furniture("LuxuryTable", "Table",  1000);
        Furniture furniture3 = new Furniture("WallClock", "Clock",  300);
        vintage.addFurniture(furniture2);
        vintage.addFurniture(furniture3);

        String expectedFurniture = "WallClock";
        String actualFurniture = String.valueOf(vintage.getCheapestFurniture());

        Assertions.assertEquals(expectedFurniture, actualFurniture);
    }


    @Test
    public void testGetPrice() {
        Furniture furniture = new Furniture("WallClock", "Clock", 100);
        Assertions.assertEquals(100, furniture.getPrice());
    }

    @Test
    public void findAllFurnitureByType() {
        Shop shop = new Shop("FurnitureWorld", 3);
        Furniture furniture2 = new Furniture("LuxuryTable", "Table", 600);
        Furniture furniture3 = new Furniture("WallClock", "Clock",  100);
        Furniture furniture4 = new Furniture("AbanosTable", "Table",  700);

        shop.addFurniture(furniture2);
        shop.addFurniture(furniture3);
        shop.addFurniture(furniture4);

        List<Furniture> foundByType = shop.findAllFurnitureByType("Table");

        Assertions.assertEquals(2, foundByType.size());
    }

    @Test
    public void testGetCapacity() {

        Assertions.assertEquals(3, shop.getCapacity());
    }

    @Test
    public void getPrice_ShouldReturnFurnituresEnergyValue() {

        Assertions.assertEquals(300, furniture.getPrice());
    }

    @Test
    public void getShopName_ShouldReturnShopName() {

        Assertions.assertEquals("VintageStuff", shop.getType());
    }

    @Test
    public void addMethod_ShouldThrowExceptionForInvalidCapacity() {
        Shop play = new Shop("Henry'sOldFurniture", 0);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            play.addFurniture(furniture);
        });
    }

    @Test
    public void addMethod_ShouldThrowExceptionForExceededCapacity() {
        Shop play = new Shop("Henry'sOldFurniture", 1);
        Furniture furniture2 = new Furniture("PrettyDesk", "Desk", 50);
        Furniture furniture3 = new Furniture("AbanosChair", "Chair",  40);

        play.addFurniture(furniture2);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            play.addFurniture(furniture3);
        });
    }

    @Test
    public void addMethod_ShouldThrowExceptionForExistingFurniture() {
        Shop play = new Shop("Henry'sOldFurniture", 3);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            play.addFurniture(furniture);
            play.addFurniture(furniture);
        });


    }

    @Test
    public void constructor_ShouldThrowArgumentExceptionForInvalidCapacity() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Shop("Ocean", -10);
        });
    }
}
import os
import django
from django.db.models import Count

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import TennisPlayer


# Create queries within functions
def get_tennis_players(search_name=None, search_country=None) -> str:
    tennis_players = ''

    if search_name is not None and search_country is not None:
        tennis_players = (TennisPlayer.objects
                          .filter(full_name__icontains=search_name, country__icontains=search_country)
                          .order_by('ranking')
                          .values('full_name', 'country', 'ranking'))

    elif search_name is None and search_country is not None:
        tennis_players = (TennisPlayer.objects.filter(country__icontains=search_country)
                          .order_by('ranking')
                          .values('full_name', 'country', 'ranking'))

    elif search_name is not None and search_country is None:
        tennis_players = (TennisPlayer.objects.filter(full_name__icontains=search_name)
                          .order_by('full_name')
                          .values('full_name', 'country', 'ranking'))

    return '\n'.join(f"Tennis Player: {p['full_name']}, country: {p['country']}, ranking: {p['ranking']}"
                     for p in tennis_players) if tennis_players != '' else tennis_players


def get_top_tennis_player():
    player_with_most_wins = TennisPlayer.objects.get_tennis_players_by_wins_count().first()
    if not player_with_most_wins:
        return ''

    return f"Top Tennis Player: {player_with_most_wins.full_name} with {player_with_most_wins.player_wins} wins."


def get_tennis_player_by_matches_count():
    player_with_most_matches = (TennisPlayer.objects.annotate(matches_played=Count('matches'))
                                .order_by('-matches_played', 'ranking').first())

    if not player_with_most_matches:
        return ''

    return (f"Tennis Player: {player_with_most_matches.full_name} with {player_with_most_matches.matches_played} "
            f"matches played.")



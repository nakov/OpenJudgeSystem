from project.trip import Trip
#from trip import Trip
import unittest


class TestTrip(unittest.TestCase):

    def setUp(self) -> None:
        self.Trip = Trip(9999, 50, 0)

    def test_successful_init(self):
        self.assertEqual(9999, self.Trip.budget)
        self.assertEqual(50, self.Trip.travelers)
        self.assertEqual(0, self.Trip.is_family)

    def test_set_get_travellers(self):
        self.Trip.travelers(100)
        result = self.Trip.travelers
        expected_outcome = 100
        self.assertEqual(result, expected_outcome)

    def test_is_family(self):
        self.Trip.travelers(1)
        self.Trip.is_family(1)
        result = self.Trip.travelers
        expected_outcome = 0
        self.assertEqual(result, expected_outcome)

    def test_book_a_trip(self):
        self.Trip.travelers(1)
        result = self.Trip.book_a_trip("Brazil")
        expected_outcome = 'Successfully booked destination Brazil! Your budget left is 3799.00'
        self.assertEqual(result, expected_outcome)

    def test_booking_status(self):
        result = self.Trip.booking_status()
        expected_outcome = """Booked Destination: Brazil
Paid Amount: 6200.00
Number of Travelers: 1
Budget Left: 3799.00"""
        self.assertEqual(result, expected_outcome)






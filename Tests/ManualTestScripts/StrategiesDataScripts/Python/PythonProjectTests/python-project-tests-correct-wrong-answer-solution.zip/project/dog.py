from project.animal import Animal


class Dog:

    def bark(self):
        return "barking..."

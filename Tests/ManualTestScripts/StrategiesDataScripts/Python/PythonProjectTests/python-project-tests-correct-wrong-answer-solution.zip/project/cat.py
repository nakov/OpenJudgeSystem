from project.animal import Animal


class Cat:

    def meow(self):
        return "meowing..."

function lockedProfile() {
    
  window.addEventListener('load', resolvingPromises);

  async function resolvingPromises(event){
    try{
      const url = await fetchFunction(`http://localhost:3030/jsonstore/advanced/profiles`);
      creatingProfile (url);
    }
    catch{
      console.error('Invalid request');
    }
  }
 
 function creatingProfile(response) {
  const mainContainer = document.querySelector('main');
  mainContainer.replaceChildren();
  
  Object.values(response).forEach(({ username, email, age }, index) => {
    const handleClick = () => {
      // Use index here
      console.log(`Clicked profile ${index + 1}`)
      // Rest of your handleClick logic
    }
    // handleClick(index)
    
    
    
//  const mainContainer = createElement("main", {id: "main"});
 
const divContainer = createElement("div", {class: "profile"});
const img = createElement("img", {src: "./iconProfile2.png", class: "userIcon"});
const label = createElement("label", {}, "Lock");
const radio1 = createElement("input", {type: "radio", name: `user${index+1}Locked`, value: "lock", checked: "true"});
const label2 = createElement("label", {}, "Unlock");
const radio2 = createElement("input", {type: "radio", name: `user${index+1}Locked`, value: "unlock"});
const brEl = createElement("br", {}, null);
const hrLine1 = createElement("hr", {}, "");
const labelName = createElement("label", {}, "Username");
const inputElement = createElement("input", {type: "text", name: `user1Username`, value: username, disabled: "true", readonly: "true"});
const nestedDivContainer = createElement("div", {class: `user1Username`});
const hrLine2 = createElement("hr", {}, "");
const labelEmail = createElement("label", {}, "Email:");
const inputEmail = createElement("input", {type: "email", name: `user1Email`, value: email, disabled: "true", readonly: "true"});
const labelAge = createElement("label", {}, "Age:");
const inputText = createElement("input", {type: "text", name: `user1Age`, value: age, disabled: "true", readonly: "true"});
const button = createElement("button", {}, "Show more");


divContainer.append(img,label,radio1,label2,radio2,brEl,hrLine1,labelName,inputElement);
nestedDivContainer.append(hrLine2,labelEmail,inputEmail,labelAge,inputText);
divContainer.append(nestedDivContainer,button);
let final = document.getElementById('main').appendChild(divContainer);


nestedDivContainer.style.display = 'none';



console.log(final);



  });

  let currentButton = document.querySelectorAll('button').forEach(e=>{
  e.addEventListener('click',handleClick);

  });
 
 }
 
 
 

 function handleClick(event) {
  const currentButton = event.target;
  const divContainer = currentButton.closest('.profile'); // Find the closest profile container
  const nestedDiv = divContainer.querySelector('.user1Username'); // Find the nested div within this profile
  const firstRadio = divContainer.querySelector('input[value="lock"]'); // Lock radio in current profile
  const secondRadio = divContainer.querySelector('input[value="unlock"]'); // Unlock radio in current profile

  // Check if the profile is locked or unlocked
  if (firstRadio.checked) {
    // If locked, stop further action
    return;
  } else if (secondRadio.checked) {
    // If unlocked, toggle visibility
    if (currentButton.textContent === 'Show more') {
      currentButton.textContent = 'Hide it';
      nestedDiv.style.display = 'block';
    } else {
      currentButton.textContent = 'Show more';
      nestedDiv.style.display = 'none';
    }
  }
}






function createElement(type, attributes = {}, content) {
    const element = document.createElement(type);
    
    Object.entries(attributes).forEach(([attr, value]) => {
      
      if (attr === 'class') {
        element.classList.add(...value.split(' '));
      } else if (attr === 'id') {
        element.id = value;
      } else if (attr === 'disabled' || attr === 'readonly') {
        if (value) element.setAttribute(attr, '');
      } else {
        element.setAttribute(attr, value);
      }
    });
  

    

    if (content) element.textContent = content;
  
    return element;
  }



async function fetchFunction(url){
const response = await fetch(url);


if(!response.ok){
 throw new Error(`HTTP request failed! status:${response.status}`);
}

 return response.json();

}

};